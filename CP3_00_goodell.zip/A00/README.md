# Martian House Hunting (For the Squirrels!)

*Goal: Find 3 potential build sites for your Martian houses. The area of the build plot should be 160000 trunks big. (pixels). The min dimension for a build plot is 100 trunk widths. The build plot must be flat. The whole terrian must remain erosion safe.  No cardinal neighbors should differ by more than 1.*

---

## Base Candidates
- Base0: (2870,20) - 400x400 - 2,764,666 Acorns
- Base1: (3646,3505) - 400x400 - 1,674,530 Acorns
- Base2: (1579,912) - 400x400 - 3,733,552 Acorns