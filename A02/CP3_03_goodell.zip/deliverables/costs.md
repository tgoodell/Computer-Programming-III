# Costs

- First to Second Road: 4445 Acorns

- Second to Third Road: 5322 Acorns

- Third to First Road: 1737 Acorns
